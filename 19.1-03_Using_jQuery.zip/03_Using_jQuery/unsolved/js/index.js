// Use jQuery to target the <h1> tag and make it red.

// Use jQuery to target the blue class and make it blue.

// Use jQuery to target the addMe ID and change its HTML to Hello.
