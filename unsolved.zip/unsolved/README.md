W3CSS Band HTML5 CSS3 Responsive Template based on  W3CSS framework.
![screenshot](images/w3css-band-screenshot.jpg)
